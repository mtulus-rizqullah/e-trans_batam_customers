import 'package:flutter/material.dart';
import 'login.dart';
import 'register.dart';
import 'home.dart';

void main() {
  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Login(),
      routes: <String, WidgetBuilder>{
        '/Register': (BuildContext context) => Register(),
        '/Home': (BuildContext context) => HomePage(),
        '/Login': (BuildContext context) => Login(),
      },
    );
  }
}

