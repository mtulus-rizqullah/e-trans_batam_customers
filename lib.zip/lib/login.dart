import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}
class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 25, vertical: 25),
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 50,
            ),
            Container(
              alignment: Alignment.topCenter,
              padding: EdgeInsets.symmetric(horizontal: 120, vertical: 120),
              child: Text(
                'Sign In',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.all(25),
              child: Column(
                children: <Widget>[
                  // Old Password
                  Row(
                    children: [
                      Container(
                        width: 300,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(40),
                          border: Border.all(color: Colors.black),
                        ),
                        height: 40,
                        child: TextField(
                          obscureText: true,
                          style: TextStyle(color: Colors.black),
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              contentPadding:
                                  EdgeInsets.only(top: 14, left: 25),
                              hintStyle: TextStyle(color: Colors.black)),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  // New Password
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Container(
                        width: 300,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(40),
                          border: Border.all(color: Colors.black),
                        ),
                        height: 40,
                        child: TextField(
                          obscureText: true,
                          style: TextStyle(color: Colors.black, fontSize: 15,  ),
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              contentPadding:
                                  EdgeInsets.only(top: 14, left: 25),
                              hintStyle: TextStyle(color: Colors.black)),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  SizedBox(height: 20),
                  // Tombol lOGIN
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 0),
                    width: 175,
                    child: RaisedButton(
                      onPressed: () {Navigator.pushNamed(context, '/Home');
                      },
                      elevation: 5,
                      padding: EdgeInsets.all(15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      color: Colors.yellow,
                      child: Text(
                        'Login',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  SizedBox(height: 30,),
                    Container(
                      child: FlatButton(
                        onPressed: (){
                          Navigator.pushNamed(context, '/Forget');
                          },
                        child: Text(
                          'Forget Passsword ?',
                          style: TextStyle(
                            color: Colors.lightBlueAccent,
                            fontSize: 16,
                          )
                      ),
                      )
                    ),
                  Container(
                      child: FlatButton(
                        onPressed: (){
                          Navigator.pushNamed(context, '/Register');
                        },
                        child: Text(
                            'Not Have Account ? Register Now',
                            style: TextStyle(
                              color: Colors.lightBlueAccent,
                              fontSize: 16,
                            )
                        ),
                      )
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
