import 'package:flutter/material.dart';

class Ticket extends StatefulWidget {
  @override
  _TicketState createState() => _TicketState();
}

class _TicketState extends State<Ticket> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Center(
        child: Column(
          children: <Widget>[
            Text(
              'Ticket',
              style: TextStyle(
                color: Colors.black,
                fontSize: 50,
              ),
            ),
            Icon(
              Icons.confirmation_num,
              size: 90,
            )
          ],
        ),
      ),
    );
  }
}
